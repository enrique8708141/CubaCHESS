# CubaCHESS - Aplicación de Ajedrez

Una aplicación de ajedrez intuitiva desarrollada con React JS para el frontend web, Node.js para el backend y React Native para la aplicación móvil.

## Descripción

CubaCHESS es una plataforma completa para jugar ajedrez que incluye:

- Landing page interactivo con historia del ajedrez y biografías de grandes maestros
- Sistema de autenticación de usuarios
- Tablero de ajedrez funcional
- Interfaz intuitiva y atractiva
- Versión web y móvil

## Estructura del Proyecto

El proyecto está organizado en tres componentes principales:

- **frontend**: Aplicación web desarrollada con React JS
- **backend**: API y servidor desarrollados con Node.js y Express
- **mobile**: Aplicación móvil desarrollada con React Native

## Tecnologías Utilizadas

### Frontend Web
- React JS
- Material-UI
- Redux para gestión de estado
- React Router para navegación

### Backend
- Node.js
- Express
- MongoDB
- Socket.IO para comunicación en tiempo real
- JWT para autenticación

### Aplicación Móvil
- React Native
- Redux para gestión de estado
- React Navigation

## Características

- Diseño responsivo para diferentes dispositivos
- Interfaz de usuario intuitiva
- Sistema de autenticación seguro
- Tablero de ajedrez interactivo
- Información histórica sobre el ajedrez
- Perfiles de grandes maestros

## Instalación y Uso

### Requisitos Previos
- Node.js (v14 o superior)
- npm o yarn
- MongoDB (para el backend)

### Instalación del Frontend
```bash
cd frontend
npm install
npm start
```

### Instalación del Backend
```bash
cd backend
npm install
npm start
```

### Instalación de la Aplicación Móvil
```bash
cd mobile
npm install
npx react-native run-android # o run-ios
```

## Despliegue

La aplicación web está desplegada en: https://dqxjjdhl.manus.space

## Licencia

Este proyecto está disponible como código abierto bajo los términos de la licencia MIT.

## Autor

Desarrollado por Manus Assistant para enrique870814141.
