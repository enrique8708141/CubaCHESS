import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Grid, 
  Paper,
  Typography
} from '@mui/material';

const ChessBoard = () => {
  const [boardState, setBoardState] = useState(initialBoardState());
  const [selectedPiece, setSelectedPiece] = useState(null);
  const [possibleMoves, setPossibleMoves] = useState([]);

  // Función para inicializar el tablero
  function initialBoardState() {
    // Crear un tablero vacío
    const emptyBoard = Array(8).fill().map(() => Array(8).fill(null));
    
    // Colocar peones
    for (let i = 0; i < 8; i++) {
      emptyBoard[1][i] = { type: 'pawn', color: 'black' };
      emptyBoard[6][i] = { type: 'pawn', color: 'white' };
    }
    
    // Colocar torres
    emptyBoard[0][0] = { type: 'rook', color: 'black' };
    emptyBoard[0][7] = { type: 'rook', color: 'black' };
    emptyBoard[7][0] = { type: 'rook', color: 'white' };
    emptyBoard[7][7] = { type: 'rook', color: 'white' };
    
    // Colocar caballos
    emptyBoard[0][1] = { type: 'knight', color: 'black' };
    emptyBoard[0][6] = { type: 'knight', color: 'black' };
    emptyBoard[7][1] = { type: 'knight', color: 'white' };
    emptyBoard[7][6] = { type: 'knight', color: 'white' };
    
    // Colocar alfiles
    emptyBoard[0][2] = { type: 'bishop', color: 'black' };
    emptyBoard[0][5] = { type: 'bishop', color: 'black' };
    emptyBoard[7][2] = { type: 'bishop', color: 'white' };
    emptyBoard[7][5] = { type: 'bishop', color: 'white' };
    
    // Colocar reinas
    emptyBoard[0][3] = { type: 'queen', color: 'black' };
    emptyBoard[7][3] = { type: 'queen', color: 'white' };
    
    // Colocar reyes
    emptyBoard[0][4] = { type: 'king', color: 'black' };
    emptyBoard[7][4] = { type: 'king', color: 'white' };
    
    return emptyBoard;
  }

  // Función para manejar el clic en una casilla
  const handleSquareClick = (row, col) => {
    // Si hay una pieza seleccionada y se hace clic en una casilla válida para mover
    if (selectedPiece && possibleMoves.some(move => move.row === row && move.col === col)) {
      // Crear una copia del estado actual del tablero
      const newBoardState = boardState.map(r => [...r]);
      
      // Mover la pieza
      newBoardState[row][col] = newBoardState[selectedPiece.row][selectedPiece.col];
      newBoardState[selectedPiece.row][selectedPiece.col] = null;
      
      // Actualizar el estado del tablero
      setBoardState(newBoardState);
      
      // Limpiar la selección y los movimientos posibles
      setSelectedPiece(null);
      setPossibleMoves([]);
    } 
    // Si se hace clic en una pieza
    else if (boardState[row][col]) {
      // Seleccionar la pieza
      setSelectedPiece({ row, col, ...boardState[row][col] });
      
      // Calcular movimientos posibles (simplificado para demostración)
      const moves = [];
      
      // Para peones blancos (movimiento simple hacia arriba)
      if (boardState[row][col].type === 'pawn' && boardState[row][col].color === 'white' && row > 0) {
        if (!boardState[row-1][col]) {
          moves.push({ row: row-1, col });
        }
        // Movimiento inicial de dos casillas
        if (row === 6 && !boardState[row-1][col] && !boardState[row-2][col]) {
          moves.push({ row: row-2, col });
        }
        // Capturas diagonales
        if (col > 0 && boardState[row-1][col-1] && boardState[row-1][col-1].color === 'black') {
          moves.push({ row: row-1, col: col-1 });
        }
        if (col < 7 && boardState[row-1][col+1] && boardState[row-1][col+1].color === 'black') {
          moves.push({ row: row-1, col: col+1 });
        }
      }
      
      // Para peones negros (movimiento simple hacia abajo)
      if (boardState[row][col].type === 'pawn' && boardState[row][col].color === 'black' && row < 7) {
        if (!boardState[row+1][col]) {
          moves.push({ row: row+1, col });
        }
        // Movimiento inicial de dos casillas
        if (row === 1 && !boardState[row+1][col] && !boardState[row+2][col]) {
          moves.push({ row: row+2, col });
        }
        // Capturas diagonales
        if (col > 0 && boardState[row+1][col-1] && boardState[row+1][col-1].color === 'white') {
          moves.push({ row: row+1, col: col-1 });
        }
        if (col < 7 && boardState[row+1][col+1] && boardState[row+1][col+1].color === 'white') {
          moves.push({ row: row+1, col: col+1 });
        }
      }
      
      // Actualizar los movimientos posibles
      setPossibleMoves(moves);
    } else {
      // Si se hace clic en una casilla vacía, limpiar la selección
      setSelectedPiece(null);
      setPossibleMoves([]);
    }
  };

  // Función para renderizar una pieza
  const renderPiece = (piece) => {
    if (!piece) return null;
    
    // Mapeo de piezas a símbolos Unicode
    const pieceSymbols = {
      'white': {
        'king': '♔',
        'queen': '♕',
        'rook': '♖',
        'bishop': '♗',
        'knight': '♘',
        'pawn': '♙'
      },
      'black': {
        'king': '♚',
        'queen': '♛',
        'rook': '♜',
        'bishop': '♝',
        'knight': '♞',
        'pawn': '♟'
      }
    };
    
    return (
      <Typography 
        variant="h3" 
        component="div" 
        sx={{ 
          userSelect: 'none',
          cursor: 'pointer',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        {pieceSymbols[piece.color][piece.type]}
      </Typography>
    );
  };

  // Renderizar el tablero
  const renderBoard = () => {
    const squares = [];
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const isLight = (row + col) % 2 === 0;
        const isSelected = selectedPiece && selectedPiece.row === row && selectedPiece.col === col;
        const isPossibleMove = possibleMoves.some(move => move.row === row && move.col === col);
        
        squares.push(
          <Grid item xs={1.5} key={`${row}-${col}`}>
            <Paper 
              sx={{ 
                backgroundColor: isSelected 
                  ? '#4caf50' 
                  : isPossibleMove 
                    ? '#81c784' 
                    : isLight 
                      ? '#f0d9b5' 
                      : '#b58863',
                aspectRatio: '1/1',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                position: 'relative'
              }}
              onClick={() => handleSquareClick(row, col)}
            >
              {renderPiece(boardState[row][col])}
              {isPossibleMove && (
                <Box 
                  sx={{ 
                    position: 'absolute',
                    width: '30%',
                    height: '30%',
                    borderRadius: '50%',
                    backgroundColor: 'rgba(0, 0, 0, 0.2)',
                    zIndex: 1
                  }} 
                />
              )}
            </Paper>
          </Grid>
        );
      }
    }
    
    return (
      <Grid 
        container 
        spacing={0.5} 
        sx={{ 
          width: '100%', 
          maxWidth: '600px',
          margin: '0 auto',
          border: '8px solid #8b4513',
          borderRadius: '4px',
          padding: '8px',
          backgroundColor: '#8b4513'
        }}
      >
        {squares}
      </Grid>
    );
  };

  return (
    <Box sx={{ width: '100%', maxWidth: '600px', margin: '0 auto' }}>
      {renderBoard()}
    </Box>
  );
};

export default ChessBoard;
