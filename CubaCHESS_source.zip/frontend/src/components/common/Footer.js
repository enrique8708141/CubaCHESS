import React from 'react';
import { Typography, Box, Container } from '@mui/material';

const Footer = () => {
  return (
    <Box component="footer" className="footer">
      <Container maxWidth="lg">
        <Typography variant="body2" align="center">
          © {new Date().getFullYear()} Aplicación de Ajedrez. Todos los derechos reservados.
        </Typography>
        <Typography variant="body2" align="center" color="textSecondary">
          Desarrollado con React, Material-UI y mucho ♥
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;
