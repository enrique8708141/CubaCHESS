import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, IconButton, Menu, MenuItem } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    handleClose();
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" component={RouterLink} to="/" sx={{ flexGrow: 1, textDecoration: 'none', color: 'white' }}>
          Ajedrez Maestro
        </Typography>
        
        {/* Menú para dispositivos móviles */}
        <Box sx={{ display: { xs: 'flex', md: 'none' } }}>
          <IconButton
            size="large"
            edge="end"
            color="inherit"
            aria-label="menu"
            onClick={handleMenu}
          >
            <MenuIcon />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={open}
            onClose={handleClose}
          >
            {isAuthenticated ? (
              <>
                <MenuItem component={RouterLink} to="/game" onClick={handleClose}>Jugar</MenuItem>
                <MenuItem component={RouterLink} to="/learn" onClick={handleClose}>Aprender</MenuItem>
                <MenuItem component={RouterLink} to="/social" onClick={handleClose}>Social</MenuItem>
                <MenuItem component={RouterLink} to="/profile" onClick={handleClose}>Perfil</MenuItem>
                <MenuItem onClick={handleLogout}>Cerrar Sesión</MenuItem>
              </>
            ) : (
              <MenuItem component={RouterLink} to="/" onClick={handleClose}>Inicio</MenuItem>
            )}
          </Menu>
        </Box>
        
        {/* Menú para pantallas medianas y grandes */}
        <Box sx={{ display: { xs: 'none', md: 'flex' } }}>
          {isAuthenticated ? (
            <>
              <Button color="inherit" component={RouterLink} to="/game">
                Jugar
              </Button>
              <Button color="inherit" component={RouterLink} to="/learn">
                Aprender
              </Button>
              <Button color="inherit" component={RouterLink} to="/social">
                Social
              </Button>
              <Button color="inherit" component={RouterLink} to="/profile">
                Perfil
              </Button>
              <Button color="inherit" onClick={logout}>
                Cerrar Sesión
              </Button>
            </>
          ) : (
            <Button color="inherit" component={RouterLink} to="/">
              Inicio
            </Button>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
