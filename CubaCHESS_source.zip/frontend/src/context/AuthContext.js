import React, { createContext, useContext, useState, useEffect } from 'react';

// Crear el contexto de autenticación
const AuthContext = createContext();

// Hook personalizado para usar el contexto de autenticación
export const useAuth = () => {
  return useContext(AuthContext);
};

// Proveedor del contexto de autenticación
export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Verificar autenticación al cargar
  useEffect(() => {
    const checkAuth = () => {
      // En una implementación real, verificaríamos el token JWT o la sesión
      const token = localStorage.getItem('authToken');
      
      if (token) {
        // Simular datos de usuario
        setUser({
          id: '123',
          name: 'Usuario de Ejemplo',
          email: 'usuario@ejemplo.com',
          rating: 1200
        });
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
      
      setIsLoading(false);
    };
    
    checkAuth();
  }, []);

  // Función para iniciar sesión
  const login = (email, password) => {
    // En una implementación real, enviaríamos una solicitud al servidor
    // y recibiríamos un token JWT
    
    // Simulación de login exitoso
    const token = 'fake-jwt-token-' + Math.random().toString(36).substring(2);
    localStorage.setItem('authToken', token);
    
    // Simular datos de usuario
    setUser({
      id: '123',
      name: 'Usuario de Ejemplo',
      email: email,
      rating: 1200
    });
    
    setIsAuthenticated(true);
    return true;
  };

  // Función para registrarse
  const register = (name, email, password) => {
    // En una implementación real, enviaríamos una solicitud al servidor
    // para crear un nuevo usuario
    
    // Simulación de registro exitoso
    return true;
  };

  // Función para cerrar sesión
  const logout = () => {
    localStorage.removeItem('authToken');
    setUser(null);
    setIsAuthenticated(false);
  };

  // Valor del contexto
  const value = {
    isAuthenticated,
    user,
    isLoading,
    login,
    register,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
