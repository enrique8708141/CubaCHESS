import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper,
  Button,
  CircularProgress
} from '@mui/material';
import ChessBoard from '../../components/chess/board/ChessBoard';
import { useNavigate } from 'react-router-dom';

const GamePage = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  // Simular verificación de autenticación
  useEffect(() => {
    const checkAuth = () => {
      // En una implementación real, verificaríamos el token JWT o la sesión
      const token = localStorage.getItem('authToken');
      
      // Para propósitos de demostración, consideramos autenticado si hay cualquier valor
      if (token) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
      
      setIsLoading(false);
    };
    
    // Simular tiempo de carga
    setTimeout(checkAuth, 1000);
  }, []);

  // Redirigir a la página de inicio si no está autenticado
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/');
    }
  }, [isLoading, isAuthenticated, navigate]);

  if (isLoading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center',
        minHeight: '80vh'
      }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Jugar Ajedrez
        </Typography>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'center',
              mb: 3
            }}>
              <ChessBoard />
            </Box>
            
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'center',
              gap: 2
            }}>
              <Button variant="contained" color="primary">
                Nuevo Juego
              </Button>
              <Button variant="outlined">
                Rendirse
              </Button>
              <Button variant="outlined" color="secondary">
                Solicitar Tablas
              </Button>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 2, mb: 3 }}>
              <Typography variant="h6" gutterBottom>
                Información de la partida
              </Typography>
              <Typography variant="body1">
                Turno: Blancas
              </Typography>
              <Typography variant="body1">
                Tiempo: 10:00
              </Typography>
              <Typography variant="body1">
                Oponente: IA (Nivel Medio)
              </Typography>
            </Paper>
            
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" gutterBottom>
                Historial de movimientos:
              </Typography>
              <Box sx={{ 
                maxHeight: '300px', 
                overflowY: 'auto',
                p: 1
              }}>
                <Typography variant="body2">
                  1. e4 e5
                </Typography>
                <Typography variant="body2">
                  2. Nf3 Nc6
                </Typography>
                <Typography variant="body2">
                  3. Bb5 a6
                </Typography>
                <Typography variant="body2">
                  4. Ba4 Nf6
                </Typography>
                <Typography variant="body2">
                  5. O-O Be7
                </Typography>
                <Typography variant="body2">
                  6. Re1 b5
                </Typography>
                <Typography variant="body2">
                  7. Bb3 d6
                </Typography>
                <Typography variant="body2">
                  8. c3 O-O
                </Typography>
                <Typography variant="body2">
                  9. h3 Nb8
                </Typography>
                <Typography variant="body2">
                  10. d4 Nbd7
                </Typography>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default GamePage;
