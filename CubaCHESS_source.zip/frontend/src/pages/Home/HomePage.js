import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Button, 
  Grid, 
  Paper,
  Card, 
  CardContent, 
  CardMedia,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  Divider,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Tabs,
  Tab,
  Chip,
  useMediaQuery,
  useTheme
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

// Componente principal de la página de inicio
const HomePage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  // Estado para los diálogos de login y registro
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  
  // Estado para las pestañas de contenido histórico
  const [tabValue, setTabValue] = useState(0);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register form state
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState('');

  // Manejadores para los diálogos
  const handleLoginOpen = () => {
    setLoginOpen(true);
  };

  const handleLoginClose = () => {
    setLoginOpen(false);
  };

  const handleRegisterOpen = () => {
    setRegisterOpen(true);
  };

  const handleRegisterClose = () => {
    setRegisterOpen(false);
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  // Manejador para cambio de pestañas
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // Simulación de login
  const handleLogin = (e) => {
    e.preventDefault();
    // Simulación de login exitoso
    localStorage.setItem('authToken', 'demo-token');
    setSnackbarMessage('Inicio de sesión exitoso');
    setSnackbarSeverity('success');
    setSnackbarOpen(true);
    handleLoginClose();
    
    // Redirección a la página de juego
    setTimeout(() => {
      window.location.href = '/game';
    }, 1500);
  };

  // Simulación de registro
  const handleRegister = (e) => {
    e.preventDefault();
    if (registerPassword !== registerConfirmPassword) {
      setSnackbarMessage('Las contraseñas no coinciden');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }
    
    // Simulación de registro exitoso
    setSnackbarMessage('Registro exitoso. Ya puedes iniciar sesión.');
    setSnackbarSeverity('success');
    setSnackbarOpen(true);
    handleRegisterClose();
  };

  // Datos de ajedrecistas famosos
  const chessPlayers = [
    {
      name: 'Garry Kasparov',
      title: 'Campeón Mundial 1985-2000',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Kasparov-34.jpg/440px-Kasparov-34.jpg',
      description: 'Considerado por muchos como el mejor jugador de ajedrez de todos los tiempos. Kasparov se convirtió en el campeón mundial más joven a los 22 años y mantuvo el título durante 15 años.',
      achievements: ['Campeón mundial más joven (22 años)', 'Número 1 del ranking durante 255 meses', 'Ganador de 8 Olimpiadas de Ajedrez']
    },
    {
      name: 'Bobby Fischer',
      title: 'Campeón Mundial 1972-1975',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Bobby_Fischer_1960_in_Leipzig.jpg/440px-Bobby_Fischer_1960_in_Leipzig.jpg',
      description: 'Prodigio estadounidense que derrotó al soviético Boris Spassky en 1972 en el "Match del Siglo" durante la Guerra Fría, convirtiéndose en un símbolo político y cultural.',
      achievements: ['Campeón de EE.UU. a los 14 años', 'Gran Maestro a los 15 años', 'Victoria 6-0 en Candidatos']
    },
    {
      name: 'Magnus Carlsen',
      title: 'Campeón Mundial 2013-2023',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Magnus_Carlsen_Tata_Steel_2013.jpg/440px-Magnus_Carlsen_Tata_Steel_2013.jpg',
      description: 'El noruego alcanzó el número uno del mundo a los 19 años y ha dominado el ajedrez moderno con un estilo versátil y una memoria prodigiosa.',
      achievements: ['Rating más alto de la historia (2882)', 'Campeón en las tres modalidades: clásico, rápido y relámpago', 'Récord de 125 partidas invicto']
    },
    {
      name: 'José Raúl Capablanca',
      title: 'Campeón Mundial 1921-1927',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Jos%C3%A9_Ra%C3%BAl_Capablanca.jpg/440px-Jos%C3%A9_Ra%C3%BAl_Capablanca.jpg',
      description: 'El cubano conocido como "La Máquina del Ajedrez" por su precisión técnica y su estilo aparentemente sin esfuerzo. Fue uno de los jugadores más dominantes de su época.',
      achievements: ['8 años sin perder una partida oficial', 'Campeón mundial cubano', 'Conocido por su precisión y finales magistrales']
    }
  ];

  // Datos históricos del ajedrez
  const chessHistory = [
    {
      period: 'Orígenes (Siglo VI)',
      event: 'Nacimiento del Chaturanga en India',
      description: 'El ajedrez moderno tiene sus raíces en el juego indio Chaturanga, que representaba los cuatro elementos del ejército: infantería, caballería, elefantes y carros.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Chaturanga.jpg/440px-Chaturanga.jpg'
    },
    {
      period: 'Expansión (Siglos VII-X)',
      event: 'Difusión a través de Persia y el mundo árabe',
      description: 'Los persas adoptaron el juego como Shatranj, y tras la conquista islámica, se extendió por todo el mundo árabe, llegando a España y Sicilia.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Chess_piece_-_White_rook.JPG/440px-Chess_piece_-_White_rook.JPG'
    },
    {
      period: 'Europa Medieval (Siglos XI-XV)',
      event: 'Evolución de las reglas modernas',
      description: 'En Europa, el juego evolucionó gradualmente: la reina ganó su poder actual, se introdujo el enroque y el peón pudo avanzar dos casillas en su primer movimiento.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Chess_piece_-_Black_queen.JPG/440px-Chess_piece_-_Black_queen.JPG'
    },
    {
      period: 'Era Romántica (1800-1880)',
      event: 'Ajedrez de ataque y sacrificios',
      description: 'Caracterizada por un estilo de juego audaz y táctico, con énfasis en ataques rápidos al rey y sacrificios espectaculares. Adolf Anderssen y Paul Morphy fueron figuras destacadas.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Paul_Morphy_by_Arnous_de_Riviere.jpg/440px-Paul_Morphy_by_Arnous_de_Riviere.jpg'
    },
    {
      period: 'Era Científica (1886-1946)',
      event: 'Sistematización del juego',
      description: 'Wilhelm Steinitz estableció las bases del ajedrez posicional moderno. Surgieron escuelas de pensamiento como la hipermoderna, que desafiaba los principios clásicos.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Wilhelm_Steinitz2.jpg/440px-Wilhelm_Steinitz2.jpg'
    },
    {
      period: 'Dominación Soviética (1945-1991)',
      event: 'El ajedrez como símbolo nacional',
      description: 'La URSS dominó el ajedrez mundial, produciendo campeones como Botvinnik, Tal, Petrosian, Spassky y Karpov. El ajedrez se convirtió en parte de la identidad nacional soviética.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Mikhail_Tal_1982.jpg/440px-Mikhail_Tal_1982.jpg'
    },
    {
      period: 'Era Digital (1997-presente)',
      event: 'Computadoras y ajedrez online',
      description: 'Deep Blue derrotó a Kasparov en 1997, marcando un hito en la inteligencia artificial. Internet democratizó el acceso al ajedrez, permitiendo jugar y aprender a millones de personas.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Kasparov-34.jpg/440px-Kasparov-34.jpg'
    }
  ];

  // Datos curiosos sobre el ajedrez
  const chessFacts = [
    "El número de posibles partidas de ajedrez únicas es mayor que el número de átomos en el universo observable.",
    "La pieza de ajedrez más antigua conocida data del año 600 d.C., descubierta en Uzbekistán.",
    "El término 'jaque mate' proviene del persa 'shah mat', que significa 'el rey está muerto'.",
    "El ajedrez fue el primer juego deportivo en tener un campeonato mundial oficial, en 1886.",
    "La partida más larga teóricamente posible podría durar 5949 movimientos.",
    "El primer programa de ajedrez fue escrito por Alan Turing en 1951, antes de que existieran las computadoras para ejecutarlo.",
    "El ajedrez es asignatura obligatoria en algunas escuelas de Armenia, el primer país en implementar esta medida.",
    "La pieza más valiosa, la reina, era originalmente la más débil, hasta que se cambió su movimiento en el siglo XV.",
    "El récord del jugador más joven en derrotar a un gran maestro lo tiene Abhimanyu Mishra, a los 10 años y 9 meses.",
    "El 'Loco del Ajedrez', Bobby Fischer, exigía que las piezas estuvieran exactamente centradas en sus casillas antes de jugar."
  ];

  return (
    <Box sx={{ 
      position: 'relative', 
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #1a237e 0%, #283593 50%, #303f9f 100%)',
      color: 'white',
      pt: 2,
      pb: 8
    }}>
      {/* Animación de piezas de ajedrez flotantes */}
      <Box sx={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        right: 0, 
        bottom: 0, 
        overflow: 'hidden',
        zIndex: 0,
        opacity: 0.1
      }}>
        {[...Array(20)].map((_, i) => (
          <Box
            key={i}
            sx={{
              position: 'absolute',
              width: '50px',
              height: '50px',
              background: `url('/assets/images/chess-piece-${i % 6}.png') no-repeat center center`,
              backgroundSize: 'contain',
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animation: `float ${5 + Math.random() * 10}s linear infinite`,
              opacity: 0.7,
              transform: `rotate(${Math.random() * 360}deg)`,
              '@keyframes float': {
                '0%': {
                  transform: 'translateY(0) rotate(0deg)',
                },
                '50%': {
                  transform: 'translateY(-20px) rotate(180deg)',
                },
                '100%': {
                  transform: 'translateY(0) rotate(360deg)',
                },
              },
            }}
          />
        ))}
      </Box>

      <Container maxWidth="xl" sx={{ position: 'relative', zIndex: 1 }}>
        {/* Encabezado con título y botones de acción */}
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mb: 4
        }}>
          <Typography 
            variant="h3" 
            component="h1" 
            sx={{ 
              fontWeight: 700,
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
            }}
          >
            El Juego Ciencia
          </Typography>
          
          <Box>
            <Button 
              variant="contained" 
              onClick={handleLoginOpen}
              sx={{ 
                mr: 2,
                backgroundColor: '#f57c00',
                '&:hover': {
                  backgroundColor: '#ef6c00',
                },
              }}
            >
              Iniciar Sesión
            </Button>
            
            <Button 
              variant="outlined" 
              onClick={handleRegisterOpen}
              sx={{ 
                borderColor: 'white',
                color: 'white',
                '&:hover': {
                  borderColor: 'white',
                  backgroundColor: 'rgba(255,255,255,0.1)',
                }
              }}
            >
              Registrarse
            </Button>
          </Box>
        </Box>
        
        {/* Sección de introducción */}
        <Grid container spacing={4} sx={{ mb: 6 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 600 }}>
              El ajedrez: más que un juego
            </Typography>
            <Typography variant="body1" paragraph sx={{ fontSize: '1.1rem' }}>
              El ajedrez es considerado tanto un arte como una ciencia y un deporte. Durante siglos, ha fascinado a reyes, científicos, artistas y personas de todas las clases sociales por su profundidad estratégica y belleza lógica.
            </Typography>
            <Typography variant="body1" paragraph sx={{ fontSize: '1.1rem' }}>
              Más allá de la competición, el ajedrez desarrolla habilidades cognitivas como el pensamiento crítico, la memoria, la concentración y la planificación estratégica. Estudios científicos han demostrado sus beneficios educativos y terapéuticos.
            </Typography>
            <Box sx={{ mt: 3 }}>
              <Button 
                variant="contained" 
                size="large" 
                onClick={handleLoginOpen}
                sx={{ 
                  py: 1.5, 
                  px: 4, 
                  fontSize: '1.1rem',
                  backgroundColor: '#f57c00',
                  '&:hover': {
                    backgroundColor: '#ef6c00',
                  },
                  boxShadow: '0 4px 20px rgba(245, 124, 0, 0.4)'
                }}
              >
                Jugar Ahora
              </Button>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box sx={{ 
              position: 'relative', 
              height: '100%', 
              minHeight: '300px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center'
            }}>
              <img 
                src="https://images.unsplash.com/photo-1560174038-594a6e2e8b28?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" 
                alt="Tablero de ajedrez artístico" 
                style={{ 
                  maxWidth: '100%', 
                  maxHeight: '400px', 
                  borderRadius: '12px',
                  boxShadow: '0 10px 30px rgba(0,0,0,0.3)'
                }} 
              />
            </Box>
          </Grid>
        </Grid>
        
        {/* Sección de datos curiosos */}
        <Paper sx={{ 
          p: 4, 
          mb: 6, 
          backgroundColor: 'rgba(255,255,255,0.9)',
          color: '#333',
          borderRadius: '12px'
        }}>
          <Typography variant="h4" gutterBottom align="center" sx={{ color: '#1a237e', fontWeight: 600 }}>
            ¿Sabías que...?
          </Typography>
          
          <Grid container spacing={3} sx={{ mt: 2 }}>
            {chessFacts.slice(0, 4).map((fact, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Box sx={{ 
                  p: 2, 
                  height: '100%', 
                  border: '1px solid #e0e0e0',
                  borderRadius: '8px',
                  transition: 'transform 0.3s',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: '0 5px 15px rgba(0,0,0,0.1)'
                  }
                }}>
                  <Typography variant="body1" align="center">
                    {fact}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Paper>
        
        {/* Sección de grandes maestros */}
        <Typography variant="h4" gutterBottom align="center" sx={{ 
          fontWeight: 600,
          textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
          mb: 4
        }}>
          Grandes Maestros de la Historia
        </Typography>
        
        <Grid container spacing={4} sx={{ mb: 6 }}>
          {chessPlayers.map((player, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card sx={{ 
                height: '100%',
                transition: 'transform 0.3s',
                '&:hover': {
                  transform: 'translateY(-10px)'
                }
              }}>
                <CardMedia
                  component="img"
                  height="240"
                  image={player.image}
                  alt={player.name}
                />
                <CardContent>
                  <Typography variant="h5" component="div" gutterBottom>
                    {player.name}
                  </Typography>
                  <Typography variant="subtitle1" color="text.secondary" gutterBottom>
                    {player.title}
                  </Typography>
                  <Typography variant="body2" paragraph>
                    {player.description}
                  </Typography>
                  <Divider sx={{ my: 1 }} />
                  <Typography variant="subtitle2" gutterBottom>
                    Logros destacados:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {player.achievements.map((achievement, i) => (
                      <Chip 
                        key={i} 
                        label={achievement} 
                        size="small" 
                        color={i % 2 === 0 ? "primary" : "secondary"}
                      />
                    ))}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
        
        {/* Sección de historia del ajedrez */}
        <Paper sx={{ 
          p: 4, 
          mb: 6, 
          backgroundColor: 'rgba(255,255,255,0.9)',
          color: '#333',
          borderRadius: '12px'
        }}>
          <Typography variant="h4" gutterBottom align="center" sx={{ color: '#1a237e', fontWeight: 600, mb: 3 }}>
            La Historia del Ajedrez
          </Typography>
          
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            variant="scrollable"
            scrollButtons="auto"
            allowScrollButtonsMobile
            sx={{ 
              mb: 3,
              '& .MuiTab-root': {
                fontWeight: 600
              }
            }}
          >
            {chessHistory.map((period, index) => (
              <Tab key={index} label={period.period} />
            ))}
          </Tabs>
          
          {chessHistory.map((period, index) => (
            <Box
              key={index}
              role="tabpanel"
              hidden={tabValue !== index}
              id={`chess-history-tabpanel-${index}`}
              aria-labelledby={`chess-history-tab-${index}`}
            >
              {tabValue === index && (
                <Grid container spacing={3} alignItems="center">
                  <Grid item xs={12} md={4}>
                    <img 
                      src={period.image} 
                      alt={period.event}
                      style={{ 
                        width: '100%', 
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} md={8}>
                    <Typography variant="h5" gutterBottom>
                      {period.event}
                    </Typography>
                    <Typography variant="body1" paragraph>
                      {period.description}
                    </Typography>
                  </Grid>
                </Grid>
              )}
            </Box>
          ))}
        </Paper>
        
        {/* Sección final de llamada a la acción */}
        <Box sx={{ 
          textAlign: 'center', 
          mb: 6,
          p: 4,
          backgroundColor: 'rgba(0,0,0,0.3)',
          borderRadius: '12px'
        }}>
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 600 }}>
            Forma parte de la historia del ajedrez
          </Typography>
          <Typography variant="body1" paragraph sx={{ maxWidth: '800px', mx: 'auto', mb: 4 }}>
            Desde sus orígenes en la antigua India hasta los torneos modernos transmitidos en línea, el ajedrez ha evolucionado pero mantiene su esencia: un juego de estrategia pura que desafía la mente humana. Únete a millones de jugadores en todo el mundo.
          </Typography>
          
          <Button 
            variant="contained" 
            size="large" 
            onClick={handleRegisterOpen}
            sx={{ 
              py: 1.5, 
              px: 6, 
              fontSize: '1.2rem',
              backgroundColor: '#f57c00',
              '&:hover': {
                backgroundColor: '#ef6c00',
              },
              boxShadow: '0 4px 20px rgba(245, 124, 0, 0.4)'
            }}
          >
            Crear una cuenta gratis
          </Button>
        </Box>
      </Container>
      
      {/* Diálogo de inicio de sesión */}
      <Dialog open={loginOpen} onClose={handleLoginClose} maxWidth="xs" fullWidth>
        <DialogTitle>Iniciar Sesión</DialogTitle>
        <form onSubmit={handleLogin}>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Correo electrónico"
              type="email"
              fullWidth
              variant="outlined"
              value={loginEmail}
              onChange={(e) => setLoginEmail(e.target.value)}
              required
            />
            <TextField
              margin="dense"
              label="Contraseña"
              type="password"
              fullWidth
              variant="outlined"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              required
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleLoginClose}>Cancelar</Button>
            <Button type="submit" variant="contained" color="primary">Iniciar Sesión</Button>
          </DialogActions>
        </form>
      </Dialog>
      
      {/* Diálogo de registro */}
      <Dialog open={registerOpen} onClose={handleRegisterClose} maxWidth="xs" fullWidth>
        <DialogTitle>Crear una cuenta</DialogTitle>
        <form onSubmit={handleRegister}>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Nombre completo"
              type="text"
              fullWidth
              variant="outlined"
              value={registerName}
              onChange={(e) => setRegisterName(e.target.value)}
              required
            />
            <TextField
              margin="dense"
              label="Correo electrónico"
              type="email"
              fullWidth
              variant="outlined"
              value={registerEmail}
              onChange={(e) => setRegisterEmail(e.target.value)}
              required
            />
            <TextField
              margin="dense"
              label="Contraseña"
              type="password"
              fullWidth
              variant="outlined"
              value={registerPassword}
              onChange={(e) => setRegisterPassword(e.target.value)}
              required
            />
            <TextField
              margin="dense"
              label="Confirmar contraseña"
              type="password"
              fullWidth
              variant="outlined"
              value={registerConfirmPassword}
              onChange={(e) => setRegisterConfirmPassword(e.target.value)}
              required
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleRegisterClose}>Cancelar</Button>
            <Button type="submit" variant="contained" color="primary">Registrarse</Button>
          </DialogActions>
        </form>
      </Dialog>
      
      {/* Snackbar para notificaciones */}
      <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose}>
        <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default HomePage;
