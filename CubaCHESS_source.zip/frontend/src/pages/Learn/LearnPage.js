import React from 'react';
import { Container, Typography, Box, Grid, Paper, Card, CardContent, CardMedia } from '@mui/material';

const LearnPage = () => {
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Aprende Ajedrez
        </Typography>
        
        <Typography variant="body1" paragraph align="center">
          Mejora tus habilidades con nuestros recursos de aprendizaje
        </Typography>
        
        <Grid container spacing={4} sx={{ mt: 2 }}>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardMedia
                component="div"
                sx={{ height: 140, backgroundColor: '#1976d2' }}
              />
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Reglas Básicas
                </Typography>
                <Typography variant="body2" color="textSecondary" paragraph>
                  Aprende los movimientos de las piezas y las reglas fundamentales del ajedrez.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardMedia
                component="div"
                sx={{ height: 140, backgroundColor: '#388e3c' }}
              />
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Tácticas
                </Typography>
                <Typography variant="body2" color="textSecondary" paragraph>
                  Domina las tácticas básicas como horquillas, clavadas y descubiertos.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardMedia
                component="div"
                sx={{ height: 140, backgroundColor: '#f57c00' }}
              />
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Estrategia
                </Typography>
                <Typography variant="body2" color="textSecondary" paragraph>
                  Aprende los principios estratégicos para mejorar tu juego a largo plazo.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <Typography variant="h5" gutterBottom sx={{ mt: 6 }}>
          Puzzles de Ajedrez
        </Typography>
        
        <Paper sx={{ p: 3, mt: 2 }}>
          <Typography variant="h6" gutterBottom>
            Puzzle del día
          </Typography>
          <Typography variant="body2" paragraph>
            Blancas juegan y ganan en 2 movimientos.
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <div style={{ width: '300px', height: '300px', backgroundColor: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Typography variant="body2" color="textSecondary">
                [Tablero de ajedrez con puzzle]
              </Typography>
            </div>
          </Box>
        </Paper>
      </Box>
    </Container>
  );
};

export default LearnPage;
