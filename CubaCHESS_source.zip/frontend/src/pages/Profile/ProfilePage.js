import React from 'react';
import { Container, Typography, Box, Grid, Paper, Avatar, List, ListItem, ListItemText, Divider } from '@mui/material';

const ProfilePage = () => {
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Perfil de Usuario
        </Typography>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Avatar 
                sx={{ width: 120, height: 120, mx: 'auto', mb: 2 }}
                alt="Usuario"
                src="/assets/images/avatar.png"
              />
              <Typography variant="h5" gutterBottom>
                Usuario de Ejemplo
              </Typography>
              <Typography variant="body1" color="textSecondary">
                Miembro desde: Mayo 2025
              </Typography>
              <Typography variant="body1" sx={{ mt: 2 }}>
                Puntuación: 1200
              </Typography>
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={8}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Estadísticas
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4">42</Typography>
                    <Typography variant="body2">Partidas</Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4">24</Typography>
                    <Typography variant="body2">Victorias</Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4">15</Typography>
                    <Typography variant="body2">Derrotas</Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center">
                    <Typography variant="h4">3</Typography>
                    <Typography variant="body2">Tablas</Typography>
                  </Box>
                </Grid>
              </Grid>
              
              <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
                Historial de Partidas Recientes
              </Typography>
              <List>
                <ListItem>
                  <ListItemText 
                    primary="Victoria vs. Jugador1" 
                    secondary="24 de Mayo, 2025 - 32 movimientos"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Derrota vs. Jugador2" 
                    secondary="22 de Mayo, 2025 - 27 movimientos"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Victoria vs. Jugador3" 
                    secondary="20 de Mayo, 2025 - 45 movimientos"
                  />
                </ListItem>
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default ProfilePage;
