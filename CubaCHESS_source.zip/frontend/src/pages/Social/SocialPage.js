import React from 'react';
import { Container, Typography, Box, Grid, Paper, List, ListItem, ListItemText, ListItemAvatar, Avatar, Divider } from '@mui/material';

const SocialPage = () => {
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Comunidad de Ajedrez
        </Typography>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Amigos
              </Typography>
              <List>
                <ListItem>
                  <ListItemAvatar>
                    <Avatar>U1</Avatar>
                  </ListItemAvatar>
                  <ListItemText 
                    primary="Usuario1" 
                    secondary="En línea - Jugando"
                  />
                </ListItem>
                <Divider variant="inset" component="li" />
                <ListItem>
                  <ListItemAvatar>
                    <Avatar>U2</Avatar>
                  </ListItemAvatar>
                  <ListItemText 
                    primary="Usuario2" 
                    secondary="Desconectado"
                  />
                </ListItem>
                <Divider variant="inset" component="li" />
                <ListItem>
                  <ListItemAvatar>
                    <Avatar>U3</Avatar>
                  </ListItemAvatar>
                  <ListItemText 
                    primary="Usuario3" 
                    secondary="En línea"
                  />
                </ListItem>
              </List>
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={8}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Partidas en Curso
              </Typography>
              <List>
                <ListItem>
                  <ListItemText 
                    primary="Usuario1 vs. Usuario4" 
                    secondary="Iniciada hace 10 minutos - 15 movimientos"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Usuario5 vs. Usuario6" 
                    secondary="Iniciada hace 5 minutos - 8 movimientos"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Usuario7 vs. Usuario8" 
                    secondary="Iniciada hace 2 minutos - 3 movimientos"
                  />
                </ListItem>
              </List>
              
              <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
                Torneos Próximos
              </Typography>
              <List>
                <ListItem>
                  <ListItemText 
                    primary="Torneo Blitz Semanal" 
                    secondary="Comienza en 2 horas - 16 participantes"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Torneo de Principiantes" 
                    secondary="Mañana a las 18:00 - 8 participantes"
                  />
                </ListItem>
                <Divider />
                <ListItem>
                  <ListItemText 
                    primary="Campeonato Mensual" 
                    secondary="30 de Mayo - 32 participantes"
                  />
                </ListItem>
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default SocialPage;
