import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Provider } from 'react-redux';
import { store } from './redux/store/store';

// Importación de pantallas
import HomeScreen from './screens/Home/HomeScreen';
import GameScreen from './screens/Game/GameScreen';
import ProfileScreen from './screens/Profile/ProfileScreen';
import LearnScreen from './screens/Learn/LearnScreen';
import SocialScreen from './screens/Social/SocialScreen';

// Configuración de navegación
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Navegador de pestañas principal
function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#1976d2',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: {
          paddingBottom: 5,
          paddingTop: 5,
          height: 60,
        },
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="Inicio" 
        component={HomeScreen} 
        options={{
          tabBarIcon: ({ color, size }) => (
            <Icon name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen 
        name="Jugar" 
        component={GameScreen} 
        options={{
          tabBarIcon: ({ color, size }) => (
            <Icon name="gamepad-variant" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen 
        name="Perfil" 
        component={ProfileScreen} 
        options={{
          tabBarIcon: ({ color, size }) => (
            <Icon name="account" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen 
        name="Aprender" 
        component={LearnScreen} 
        options={{
          tabBarIcon: ({ color, size }) => (
            <Icon name="school" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen 
        name="Social" 
        component={SocialScreen} 
        options={{
          tabBarIcon: ({ color, size }) => (
            <Icon name="account-group" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// Componente de icono (placeholder)
function Icon({ name, color, size }) {
  // En una implementación real, importaríamos y usaríamos react-native-vector-icons
  return null;
}

// Navegador principal de la aplicación
export default function App() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Main">
          <Stack.Screen 
            name="Main" 
            component={MainTabNavigator} 
            options={{ headerShown: false }}
          />
          {/* Aquí se pueden agregar más pantallas que no estén en las pestañas */}
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}
