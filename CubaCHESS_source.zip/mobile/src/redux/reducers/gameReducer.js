import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  currentGame: null,
  gameHistory: [],
  isPlaying: false,
  opponent: null,
  gameMode: null, // 'ai', 'online', 'friend'
  difficulty: 'medium', // Para juegos contra IA
  boardPosition: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', // Posición FEN inicial
  moves: [],
  playerColor: 'white',
  timeControl: {
    white: 600, // 10 minutos en segundos
    black: 600,
  },
  gameResult: null, // 'checkmate', 'stalemate', 'draw', 'resignation', etc.
  loading: false,
  error: null,
};

const gameSlice = createSlice({
  name: 'game',
  initialState,
  reducers: {
    startGame: (state, action) => {
      state.isPlaying = true;
      state.gameMode = action.payload.gameMode;
      state.opponent = action.payload.opponent;
      state.difficulty = action.payload.difficulty || 'medium';
      state.playerColor = action.payload.playerColor || 'white';
      state.boardPosition = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      state.moves = [];
      state.timeControl = action.payload.timeControl || {
        white: 600,
        black: 600,
      };
      state.gameResult = null;
      state.currentGame = {
        id: action.payload.gameId,
        startTime: new Date().toISOString(),
      };
    },
    makeMove: (state, action) => {
      state.moves.push(action.payload.move);
      state.boardPosition = action.payload.newPosition;
    },
    updateTime: (state, action) => {
      state.timeControl[action.payload.color] = action.payload.time;
    },
    endGame: (state, action) => {
      state.isPlaying = false;
      state.gameResult = action.payload.result;
      if (state.currentGame) {
        state.gameHistory.push({
          ...state.currentGame,
          endTime: new Date().toISOString(),
          result: action.payload.result,
          moves: [...state.moves],
        });
      }
      state.currentGame = null;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
});

export const { startGame, makeMove, updateTime, endGame, setError, clearError } = gameSlice.actions;
export default gameSlice.reducer;
